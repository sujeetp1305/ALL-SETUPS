wget https://github.com/opentofu/opentofu/releases/download/v1.6.0-alpha3/tofu_1.6.0-alpha_linux_amd64.zip
unzip tofu_1.6.0-alpha3_linux_amd64.zip 
mv tofu /usr/local/bin/tofu 
tofu version
